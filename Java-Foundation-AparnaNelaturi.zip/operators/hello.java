import java.util.Scanner;
class hello
  {
    public static void main(String args[]);
    {
      int x;char y;double z;string h;
      Scanner d=new Scanner(System.in);
    System.out.println("enter values of x,y,z,h");
      x=d.nextInt();
      y=d.next()CharAt(0);
      z=d.nextDouoble();
      h=d.next();
      System.out.println("x valus is"+x);
      System.out.println("y valus is"+y);
      System.out.println("z valus is"+z);
      System.out.println("h valus is"+h);

    }
  }